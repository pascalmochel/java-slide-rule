#!/bin/sh

java -jar martinson-slide-rule.jar org.homs.slide.SlideRuleMain
