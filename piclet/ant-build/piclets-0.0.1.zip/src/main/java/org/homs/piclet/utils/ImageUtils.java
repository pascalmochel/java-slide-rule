//package org.homs.piclet.utils;
//
//import java.io.InputStream;
//
//public class ImageUtils {
//
//	public static InputStream loadImage(final String fileName) {
//		final InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
//		if (is == null) {
//			throw new RuntimeException("could not open configuration file: " + fileName);// TODO
//		}
//		return is;
//	}
//
// }
